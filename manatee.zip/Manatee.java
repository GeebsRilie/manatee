package man;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

/**
 * Manatee - Geerah
 * Created using Tabula 7.1.0
 */
public class Manatee extends ModelBase {
    public ModelRenderer Body;
    public ModelRenderer Tail01;
    public ModelRenderer Neck;
    public ModelRenderer Head;
    public ModelRenderer Nose;
    public ModelRenderer Tail02;
    public ModelRenderer Tail03;
    public ModelRenderer Tail04;
    public ModelRenderer Tail05;
    public ModelRenderer Tail06;
    public ModelRenderer Tail07;
    public ModelRenderer WhiskerLMid;
    public ModelRenderer WhiskerLTop;
    public ModelRenderer WhiskerLBottom;
    public ModelRenderer FinLTop;
    public ModelRenderer FinLMid;
    public ModelRenderer FinLBottom;
    public ModelRenderer WhiskerRMid;
    public ModelRenderer WhiskerRTop;
    public ModelRenderer WhiskerRBottom;
    public ModelRenderer FinRTop;
    public ModelRenderer FinRMid;
    public ModelRenderer FinRBottom;

    public Manatee() {
        this.textureWidth = 140;
        this.textureHeight = 120;
        this.FinLTop = new ModelRenderer(this, 27, 77);
        this.FinLTop.setRotationPoint(7.6F, 5.7F, 0.7F);
        this.FinLTop.addBox(0.0F, 0.0F, 0.0F, 6, 3, 15, 0.0F);
        this.setRotateAngle(FinLTop, 0.0F, 0.0F, 0.39269908169871914F);
        this.Tail03 = new ModelRenderer(this, 38, 48);
        this.Tail03.setRotationPoint(0.4F, 1.2F, 3.3F);
        this.Tail03.addBox(-5.7F, -0.5F, -2.1F, 13, 12, 5, 0.0F);
        this.setRotateAngle(Tail03, -0.2530727415391778F, 0.0F, 0.0F);
        this.WhiskerLTop = new ModelRenderer(this, 0, 0);
        this.WhiskerLTop.setRotationPoint(5.2F, 2.8F, -10.9F);
        this.WhiskerLTop.addBox(0.0F, 0.0F, 0.0F, 3, 0, 1, 0.0F);
        this.setRotateAngle(WhiskerLTop, 0.0F, 0.0F, -0.22759093446006054F);
        this.WhiskerLMid = new ModelRenderer(this, 0, 0);
        this.WhiskerLMid.setRotationPoint(5.2F, 4.7000000000000055F, -10.899999999999986F);
        this.WhiskerLMid.addBox(0.0F, 0.0F, 0.0F, 3, 0, 1, 0.0F);
        this.setRotateAngle(WhiskerLMid, 0.25621433419276723F, -0.136659280431156F, 0.0F);
        this.WhiskerRBottom = new ModelRenderer(this, 0, 0);
        this.WhiskerRBottom.setRotationPoint(-6.899999999999997F, 6.4F, -11.3F);
        this.WhiskerRBottom.addBox(0.0F, 0.0F, 0.0F, 3, 0, 1, 0.0F);
        this.setRotateAngle(WhiskerRBottom, 0.0F, 0.0F, -0.22759093446006054F);
        this.FinRMid = new ModelRenderer(this, 64, 74);
        this.FinRMid.setRotationPoint(6.9F, 0.4F, 5.9F);
        this.FinRMid.addBox(0.0F, 0.0F, -5.0F, 9, 2, 13, 0.0F);
        this.setRotateAngle(FinRMid, 0.0F, 0.0F, 0.7853981633974483F);
        this.WhiskerRMid = new ModelRenderer(this, 0, 0);
        this.WhiskerRMid.setRotationPoint(-6.9F, 4.9F, -11.3F);
        this.WhiskerRMid.addBox(0.0F, 0.0F, 0.0F, 3, 0, 1, 0.0F);
        this.setRotateAngle(WhiskerRMid, 0.25621433419276757F, 0.0F, 0.0F);
        this.Body = new ModelRenderer(this, 0, 0);
        this.Body.setRotationPoint(0.1F, -3.5000000000000013F, 0.0F);
        this.Body.addBox(-7.5F, -3.3F, 0.0F, 16, 16, 32, 0.0F);
        this.Neck = new ModelRenderer(this, 0, 0);
        this.Neck.setRotationPoint(0.1F, 0.4F, -2.1F);
        this.Neck.addBox(-6.7F, -3.0F, 0.0F, 14, 14, 4, 0.0F);
        this.setRotateAngle(Neck, 0.12950343049797697F, 4.6504913306781755E-17F, 0.0F);
        this.FinRBottom = new ModelRenderer(this, 0, 16);
        this.FinRBottom.setRotationPoint(8.7F, -0.7F, 1.3F);
        this.FinRBottom.addBox(0.0F, 0.0F, -4.1F, 7, 1, 9, 0.0F);
        this.setRotateAngle(FinRBottom, 0.0F, 0.0F, 0.39426987802551905F);
        this.FinLMid = new ModelRenderer(this, 56, 89);
        this.FinLMid.setRotationPoint(6.9F, 0.4F, 5.9F);
        this.FinLMid.addBox(0.0F, 0.0F, -5.0F, 9, 2, 13, 0.0F);
        this.setRotateAngle(FinLMid, 0.0F, 0.0F, 0.8133234314293576F);
        this.WhiskerLBottom = new ModelRenderer(this, 0, 0);
        this.WhiskerLBottom.setRotationPoint(5.2F, 6.2F, -10.9F);
        this.WhiskerLBottom.addBox(0.0F, 0.0F, 0.0F, 3, 0, 1, 0.0F);
        this.setRotateAngle(WhiskerLBottom, 0.0F, 0.0F, 0.22759093446006054F);
        this.WhiskerRTop = new ModelRenderer(this, 0, 0);
        this.WhiskerRTop.setRotationPoint(-6.9F, 3.0F, -11.3F);
        this.WhiskerRTop.addBox(0.0F, 0.0F, 0.0F, 3, 0, 1, 0.0F);
        this.setRotateAngle(WhiskerRTop, 0.2813470754214859F, 0.0F, 0.22689280275926282F);
        this.FinLBottom = new ModelRenderer(this, 95, 74);
        this.FinLBottom.setRotationPoint(8.7F, -0.7F, 1.3F);
        this.FinLBottom.addBox(0.0F, 0.0F, -4.1F, 7, 1, 9, 0.0F);
        this.setRotateAngle(FinLBottom, 0.0F, 0.0F, 0.45535640184532045F);
        this.Tail01 = new ModelRenderer(this, 64, 0);
        this.Tail01.setRotationPoint(-0.5F, -5.599999999999999F, 33.1F);
        this.Tail01.addBox(-5.7F, -0.5F, -2.1F, 14, 15, 5, 0.0F);
        this.setRotateAngle(Tail01, -0.1535889741755005F, 0.0F, 0.0F);
        this.Head = new ModelRenderer(this, 84, 36);
        this.Head.setRotationPoint(-0.7F, 2.0F, -8.2F);
        this.Head.addBox(-5.2F, -3.0F, 0.0F, 12, 12, 12, 0.0F);
        this.setRotateAngle(Head, 0.16458454846306528F, 0.0F, 0.0F);
        this.Tail06 = new ModelRenderer(this, 29, 65);
        this.Tail06.setRotationPoint(-2.6F, 2.2F, 4.0F);
        this.Tail06.addBox(-5.7F, -0.5F, -2.1F, 15, 3, 9, 0.0F);
        this.setRotateAngle(Tail06, 0.27314402793711134F, 0.0F, 0.0F);
        this.Tail05 = new ModelRenderer(this, 97, 15);
        this.Tail05.setRotationPoint(0.7F, 0.9F, 3.3F);
        this.Tail05.addBox(-5.7F, -0.5F, -2.1F, 10, 10, 5, 0.0F);
        this.setRotateAngle(Tail05, 0.015707963267948967F, 0.0F, 0.0F);
        this.FinRTop = new ModelRenderer(this, 0, 68);
        this.FinRTop.setRotationPoint(-6.800000000000004F, 5.3F, 15.999999999999954F);
        this.FinRTop.addBox(0.0F, 0.0F, 0.0F, 6, 3, 15, 0.0F);
        this.setRotateAngle(FinRTop, -0.0027925268031909274F, 3.1417671865149903F, 12.04992768869408F);
        this.Nose = new ModelRenderer(this, 102, 0);
        this.Nose.setRotationPoint(0.1F, 2.9F, -4.2F);
        this.Nose.addBox(-4.2F, -1.8F, 0.3F, 10, 9, 4, 0.0F);
        this.setRotateAngle(Nose, 0.14172073526193954F, 0.0F, 0.0F);
        this.Tail02 = new ModelRenderer(this, 0, 48);
        this.Tail02.setRotationPoint(-0.1F, 0.4F, 2.7F);
        this.Tail02.addBox(-5.7F, -0.5F, -2.1F, 14, 15, 5, 0.0F);
        this.setRotateAngle(Tail02, -0.153588974175501F, 0.0F, 0.0F);
        this.Tail07 = new ModelRenderer(this, 64, 22);
        this.Tail07.setRotationPoint(1.3F, 1.4F, 4.0F);
        this.Tail07.addBox(-5.7F, -0.5F, -2.1F, 12, 2, 8, 0.0F);
        this.setRotateAngle(Tail07, 0.27314402793711257F, 0.0F, 0.0F);
        this.Tail04 = new ModelRenderer(this, 74, 58);
        this.Tail04.setRotationPoint(0.5F, 1.1F, 3.3F);
        this.Tail04.addBox(-5.7F, -0.5F, -2.1F, 12, 11, 5, 0.0F);
        this.setRotateAngle(Tail04, -0.2530727415391778F, 0.0F, 0.0F);
        this.Tail02.addChild(this.Tail03);
        this.FinRTop.addChild(this.FinRMid);
        this.Body.addChild(this.Neck);
        this.FinRMid.addChild(this.FinRBottom);
        this.FinLTop.addChild(this.FinLMid);
        this.FinLMid.addChild(this.FinLBottom);
        this.Neck.addChild(this.Head);
        this.Tail05.addChild(this.Tail06);
        this.Tail04.addChild(this.Tail05);
        this.Head.addChild(this.Nose);
        this.Tail01.addChild(this.Tail02);
        this.Tail06.addChild(this.Tail07);
        this.Tail03.addChild(this.Tail04);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        this.FinLTop.render(f5);
        this.WhiskerLTop.render(f5);
        this.WhiskerLMid.render(f5);
        this.WhiskerRBottom.render(f5);
        this.WhiskerRMid.render(f5);
        this.Body.render(f5);
        this.WhiskerLBottom.render(f5);
        this.WhiskerRTop.render(f5);
        this.Tail01.render(f5);
        this.FinRTop.render(f5);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
